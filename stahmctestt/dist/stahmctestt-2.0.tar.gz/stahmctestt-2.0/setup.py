import setuptools

setuptools.setup(
    name="stahmctestt",
    version="2.0",
    author="TZ RO ",
    author_email="thuizhou@outlook.com",
    description="testversion",
    url="https://github.com/RihuiOu95/HMC.git",
    packages=["stahmctestt"],
    zip_safe=False
)